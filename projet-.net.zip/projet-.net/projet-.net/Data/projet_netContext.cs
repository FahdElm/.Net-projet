﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using e_commerce_1.Models;

namespace projet_.net.Data
{
    public class projet_netContext : DbContext
    {
        public projet_netContext (DbContextOptions<projet_netContext> options)
            : base(options)
        {
        }

        public DbSet<e_commerce_1.Models.Produit> Produit { get; set; } = default!;
    }
}
