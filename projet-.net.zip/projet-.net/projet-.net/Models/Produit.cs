﻿namespace e_commerce_1.Models
{
    public class Produit
    {
        public int Id { get; set; }
        public string nom { get; set; }
        public double prix { get; set; }
        public string photo { get; set; }

        public category category { get; set; }
    }
}
