﻿namespace e_commerce_1.Models
{
    public enum category
    {
        phone,
        tv,
        speakers
    }
}
